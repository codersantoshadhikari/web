+++
chatper = true
title = 'Dart Asynchronous Programming'
weight = 12
+++
### Dart Asynchronous Programming

1. Asynchronous Programming in Dart
Dart uses asynchronous programming to perform tasks that might take time, like I/O operations, without blocking the main thread. This is done using Future, async, await, and Stream.
2. Future in Dart
A Future represents a potential value or error that will be available at some time in the future. It's used for asynchronous operations which return a single value.
Example:
dart

Copy code
Future<String> fetchUserOrder() { return Future.delayed(Duration(seconds: 2), () => 'Large Latte'); } void main() { fetchUserOrder().then((order) => print('Order is ready: $order')); }
3. Async and Await in Dart
The async and await keywords provide a declarative way to define asynchronous functions and wait for asynchronous operations to complete. They help you write asynchronous code that looks synchronous.
Example:
dart

Copy code
Future<String> fetchUserOrder() async { await Future.delayed(Duration(seconds: 4)); return 'Large Cappuccino'; } void main() async { var order = await fetchUserOrder(); print('Order is ready: $order'); }
4. Stream in Dart
Streams provide a way to receive a sequence of data asynchronously. Streams are especially useful for reading data from a source that delivers chunks of data over time.
Example:
dart

Copy code
Stream<int> numberStream() async* { for (int i = 1; i <= 3; i++) { await Future.delayed(Duration(seconds: 1)); yield i; } } void main() async { await for (var number in numberStream()) { print('Received: $number'); } }
