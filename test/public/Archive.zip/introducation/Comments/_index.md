+++
chatsper = true
title = 'Comments'
weight = 6
+++
# Comments in Dart

In Dart, comments are used to annotate the code for better understanding and documentation. There are two types of comments supported in Dart:

1. **Single-line comments:** Single-line comments start with `//` and continue until the end of the line. They are commonly used for brief explanations or annotations on a single line of code.

    ```dart
    // This is a single-line comment
    var x = 5; // Variable assignment
    ```

2. **Multi-line comments:** Multi-line comments start with `/*` and end with `*/`. They can span multiple lines and are typically used for longer explanations or commenting out blocks of code.

    ```dart
    /*
    This is a multi-line comment
    It can span across multiple lines
    */
    ```

Comments are ignored by the Dart compiler and have no impact on the execution of the program. They are solely for the benefit of developers to understand the code or to temporarily disable portions of code.

## When to Use Comments

Comments should be used to explain why the code is written the way it is, especially if it might not be immediately obvious to someone reading the code. Good places to use comments include:

- Explaining complex algorithms or logic.
- Documenting the purpose of variables, functions, or classes.
- Providing context for non-obvious code.

## Best Practices for Writing Comments

1. **Be concise:** Write comments that are clear and to the point. Avoid unnecessary verbosity.
2. **Keep comments up-to-date:** Make sure to update comments when code changes to ensure they remain accurate.
3. **Use meaningful names:** Good variable, function, and class names can reduce the need for comments by making the code self-explanatory.
4. **Avoid redundant comments:** Don't write comments that simply restate what the code does unless it's absolutely necessary for clarity.
5. **Use comments to explain 'why,' not 'what':** Comments should focus on explaining the reasons behind the code, rather than describing what the code is doing (unless the 'what' is not immediately obvious).

## Example

Here's an example demonstrating the use of comments in Dart:

```dart
// This function calculates the sum of two numbers
int add(int a, int b) {
  return a + b; // Return the sum
}

/* 
This class represents a person with a name and age.
It provides methods to get and set the name and age.
*/
class Person {
  String name; // Name of the person
  int age; // Age of the person

  // Constructor
  Person(this.name, this.age);

  // Method to print the person's details
  void printDetails() {
    print('Name: $name, Age: $age');
  }
}

void main() {
  // Creating a new person object
  var person = Person('Alice', 30);
  // Printing the person's details
  person.printDetails();
}
