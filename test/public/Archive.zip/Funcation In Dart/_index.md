+++
chatper = true
title = 'Function in Dart'
weight = 12
+++
### Function in Dart


1. Function in Dart
In Dart, a function is a set of statements organized together to perform a specific task. Functions in Dart can return a value or simply perform a side effect without returning anything.
Example:
dart

Copy code
void greet() { print('Hello, world!'); }
2. Types of Functions in Dart
There are mainly two types of functions in Dart:
* Named functions: Declared with a name and can be called using their name.
* Anonymous functions: Also known as lambda functions or closures, these functions are not named and are often used for short tasks.
Example:
dart

Copy code
// Named function int add(int a, int b) { return a + b; } // Anonymous function var multiply = (int a, int b) => a * b;
3. Function Parameters in Dart
Functions in Dart can take parameters, which are specified during the function call. Parameters can be required or optional.
Example:
dart

Copy code
void sayHello(String name) { print('Hello, $name!'); }
4. Anonymous Function in Dart
Anonymous functions in Dart do not have a name and are typically used in places where a function is needed temporarily.
Example:
dart

Copy code
var list = ['apples', 'bananas', 'oranges']; list.forEach((item) { print(item); });
5. Arrow Function in Dart
Arrow functions in Dart are a shorthand syntax for writing functions that have only one expression. They are useful for concise function declarations.
Example:
dart

Copy code
int add(int a, int b) => a + b;
6. Scope in Dart
The scope of a variable defines where the variable can be accessed within the code. Dart has both local and global scopes.
Example:
dart

Copy code
void main() { int insideMain = 1; // Local to main void nestedFunction() { int insideNested = 2; // Local to nestedFunction print(insideMain); // Accessible here } nestedFunction(); }
7. Math in Dart
Dart provides a Math library that contains functions to perform mathematical operations such as trigonometric, exponential, and logarithmic functions among others.
Example:
dart

Copy code
import 'dart:math'; void main() { print(sin(pi/2)); // Prints 1.0 }
