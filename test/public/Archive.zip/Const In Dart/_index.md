+++
chatper = true
title = 'Const In Dart'
weight = 12
+++
###  Const in Dart

1. Final and Const in Dart
Dart uses final and const keywords to handle immutable data. The key difference between them is that final variables can only be set once and initialized when accessed, whereas const variables are implicitly final but must be declared and initialized as compile-time constants.
* Final: Used when you want a variable to be set only once and initialized when it is accessed.dart  Copy… final String name = ’Santosh;  . 
* Const: Used for variables that are constants at compile time.dart  Copy ….. const double pi = 3.14159;   
2. Date and Time in Dart
Dart provides extensive support for date and time operations through its DateTime class, which is part of the core library.
* Example: Creating and manipulating DateTime objects.dart  Copy …… DateTime now = DateTime.now(); DateTime firstDay = DateTime(2024, 1, 1); DateTime twoHoursLater = now.add(Duration(hours: 2));   
3. Extension Methods in Dart
Extension methods allow you to add new functionalities to existing classes. This is particularly useful for adding methods to classes from a library that you don’t have the ability to change directly.
* Example: Adding a method to the String class to check if the string is a palindrome.dart  Copy ………… extension StringExtension on String { bool get isPalindrome { String cleaned = this.replaceAll(RegExp(r'[\W_]'), '').toLowerCase(); return cleaned == cleaned.split('').reversed.join(''); } } print('radar'.isPalindrome); // true 
* 
* Si 
