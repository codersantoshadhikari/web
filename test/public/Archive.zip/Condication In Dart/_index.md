+++
chatper = true
title = 'Conditions in Dart'
weight = 10
+++
### Conditions in Dart
1. Conditions in Dart
Dart uses typical conditional statements like if, else if, and else. Conditions evaluate Boolean expressions and execute code blocks based on their truth value.
Example:
dart


int number = 5; if (number > 0) { print("Positive"); } else if (number < 0) { print("Negative"); } else { print("Zero"); }
2. Loops in Dart
Dart includes several types of loops to handle repetitive tasks, including for, while, and do-while loops.
3. For Loop in Dart
Executes a block of code a specific number of times.
Example:
dart


for (int i = 0; i < 5; i++) { print('Hello ${i}'); }
4. For Each Loop in Dart
Iterates over elements in a collection (like a list or set).
Example:
dart


var numbers = [1, 2, 3]; for (var n in numbers) { print(n); }
5. While Loop in Dart
Continues executing a block of code as long as a condition is true.
Example:
dart


int num = 5; while (num > 0) { print(num); num--; }
6. Do While Loop in Dart
Similar to the while loop, but guarantees at least one execution of the block.
Example:
dart


int num = 5; do { print(num); num--; } while (num > 0);
7. Switch Case in Dart
Allows execution of different code blocks based on the value of a variable.
Example:
dart


var command = 'OPEN'; switch (command) { case 'OPEN': print('Opening'); break; case 'CLOSE': print('Closing'); break; default: print('Invalid command'); }
8. Break and Continue in Dart
break exits the loop, while continue skips to the next iteration.
Example:
dart


for (int i = 0; i < 10; i++) { if (i == 5) continue; if (i == 8) break; print(i); }
9. Ternary Operator in Dart
A shorthand for if-else used to assign values based on a condition.
Example:
dart


var accessAllowed = age > 18 ? true : false;
10. Exception Handling in Dart
Manages errors and exceptional events using try, catch, and finally blocks.
Example:
dart


try { var result = 100 / 0; } catch (e) { print('Exception happened: $e'); } finally { print('This block runs whether an exception occurs or not'); }
