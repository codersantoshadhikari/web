+++
chatsper = true
title = 'Basic  Program '
weight = 2
+++

In this tutorial, we'll go through the process of writing, understanding, and running a simple Dart program that prints "Hello, World!" to the console.

## Prerequisites

- Ensure Dart is installed on your system. You can verify this by running `dart --version` in your terminal or command prompt.

## Creating Your First Dart Program

### Step 1: Set Up Your Project

1. **Create a New Directory:**
   - Create a new folder for your Dart project. You can name it anything, for example, `hello_dart`.
   - Navigate into your new directory:
     ```bash
     mkdir hello_dart
     cd hello_dart
     ```

2. **Create a Dart File:**
   - Inside the directory, create a new file named `main.dart`.
   - You can do this using a text editor, or by running the following command in the terminal:
     ```bash
     touch main.dart
     ```

### Step 2: Write the Dart Code

1. **Open `main.dart` in Your Text Editor:**
   - Add the following Dart code to the file:
     ```dart
     void main() {
       print('Hello, World!');
     }
     ```

[Click Me](https://dartpad.dev/?id=016096a3bd6b51a0b6a4bfffde18a0fb) 

   - This program starts with a `main` function, which is the entry point of many programming languages, including Dart.
   - The `print()` function is used to output text to the console.

### Step 3: Run Your Dart Program

1. **Execute the Program:**
   - Open your terminal or command prompt.
   - Navigate to the directory containing your `main.dart` file.
   - Run the program by typing:
     ```bash
     dart run main.dart
     ```

2. **View the Output:**
   - If everything is set up correctly, you will see `Hello, World!` printed in the terminal.

## Understanding the Code

- **`void main()`**: This declares the main function. `void` indicates that this function does not return a value.
- **`print('Hello, World!')`**: This line outputs the string `Hello, World!` to the console.

## Next Steps

After running your first program, you might want to explore more about Dart:

- **Variables and Types**: Learn about declaring and using variables in Dart.
- **Control Structures**: Explore how to use `if` statements, loops, and other control structures.
- **Functions**: Understand how to define and invoke functions.
- **Classes and Objects**: Dive into object-oriented programming with Dart.

Explore these topics by visiting the [official Dart documentation](https://dart.dev/guides).

