+++
chatper = true
title = 'Read File In Dart'
weight = 12
+++
### Read File in Dart

1. Read File in Dart
To read a file in Dart, you can use the File class and its method readAsString() for text files. This reads the entire file content as a single string.
Example:
dart

Copy code
import 'dart:io'; void main() async { var file = File('path/to/your/file.txt'); try { String contents = await file.readAsString(); print(contents); } catch (e) { print('Error reading file: $e'); } }
2. Write File in Dart
Writing to a file in Dart can also be achieved with the File class. Use the writeAsString() method to write text to a file. This method writes a string to a file, overwriting the existing content unless specified otherwise.
Example:
dart

Copy code
import 'dart:io'; void main() async { var file = File('path/to/your/file.txt'); try { await file.writeAsString('Hello, Dart!'); print('File written successfully'); } catch (e) { print('Error writing to file: $e'); } }
3. Delete File in Dart
To delete a file, use the delete() method from the File class. This method deletes the file if it exists.
Example:
dart

Copy code
import 'dart:io'; void main() async { var file = File('path/to/your/file.txt'); try { if (await file.exists()) { await file.delete(); print('File deleted successfully'); } else { print('File does not exist'); } } catch (e) { print('Error deleting file: $e'); } }
