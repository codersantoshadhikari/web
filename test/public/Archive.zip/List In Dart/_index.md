+++
chatper = true
title = 'List in Dart'
weight = 12
+++
### List in Dart

1 .List in Dart
A List in Dart is an ordered group of objects. The elements of a List can be accessed using their indexes. Dart supports both fixed-length and growable lists.
Example:
dart

Copy code
List<String> fruits = ['Apple', 'Banana', 'Cherry']; print(fruits[1]); // Output: Banana
2. Set in Dart
A Set in Dart is an unordered collection of unique items. This means it does not allow duplicates, which makes it useful for ensuring an item appears only once in a collection.
Example:
dart

Copy code
Set<int> numbers = {1, 2, 3, 4}; numbers.add(3); // No effect since 3 is already present print(numbers); // Output: {1, 2, 3, 4}
3. Map in Dart
A Map is a collection of key-value pairs. Keys in a map are unique, and each key maps to exactly one value. Maps are useful for looking up values by their associated keys.
Example:
dart

Copy code
Map<String, String> capitals = { 'France': 'Paris', 'India': 'New Delhi', }; print(capitals['France']); // Output: Paris
4. Where in Dart
where is not a collection, but a method available on collections like Lists and Sets. It's used to filter collections based on a condition, returning an iterable that only contains elements that match the given condition.
Example:
dart

Copy code
List<int> numbers = [1, 2, 3, 4, 5]; Iterable<int> evenNumbers = numbers.where((number) => number % 2 == 0); print(evenNumbers); // Output: (2, 4)
