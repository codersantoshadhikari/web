+++
chatsper = true
title = 'Installing Dart'
weight = 1
+++


This guide provides a step-by-step process for installing Dart on various operating systems.

## Prerequisites

Before installing Dart, make sure you have the following:

- An internet connection.
- Administrative access to your computer.

## Installation on Windows

1. **Download the Dart SDK:**
   - Visit the official Dart SDK archives [here](https://dart.dev/tools/sdk/archive).
   - Choose the version suitable for Windows and download the zip file.

2. **Extract the SDK:**
   - Extract the contents of the downloaded zip file to a directory of your choice (e.g., `C:\Dart`).

3. **Update your PATH:**
   - Search for 'Environment Variables' in your Windows search and select "Edit the system environment variables".
   - In the System Properties window, click on "Environment Variables".
   - Under "System variables", find and select "Path", then click "Edit".
   - Click "New" and add the path to your Dart SDK's `bin` directory (e.g., `C:\Dart\dart-sdk\bin`).
   - Click "OK" to close all dialogs.

4. **Verify Installation:**
   - Open a new command prompt and type `dart --version` to check if Dart is correctly installed.

## Installation on macOS

1. **Install Homebrew:**
   - If not already installed, open a terminal and run:
     ```bash
     /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
     ```

2. **Install Dart:**
   - Using Homebrew, install Dart by running:
     ```bash
     brew tap dart-lang/dart
     brew install dart
     ```

3. **Verify Installation:**
   - In your terminal, type `dart --version` to ensure Dart is installed correctly.

## Installation on Linux

1. **Enable apt over HTTPS:**
   - Run the following commands in your terminal:
     ```bash
     sudo apt-get update
     sudo apt-get install apt-transport-https
     ```

2. **Set up Dart repository:**
   - Run these commands to add the Dart repository to your system:
     ```bash
     sudo sh -c 'wget -qO- https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add -'
     sudo sh -c 'wget -qO- https://storage.googleapis.com/download.dartlang.org/linux/debian/dart_stable.list > /etc/apt/sources.list.d/dart_stable.list'
     ```

3. **Install Dart SDK:**
   - Update your package list and install the Dart SDK:
     ```bash
     sudo apt-get update
     sudo apt-get install dart
     ```

4. **Verify Installation:**
   - Run `dart --version` in your terminal to check the Dart SDK installation.

## Next Steps

After installing Dart, you might want to:

- Explore Dart packages on [Pub.dev](https://pub.dev/).
- Learn more about Dart by visiting [official tutorials](https://dart.dev/tutorials).
- Start your first Dart project!

Feel free to adjust paths and settings according to your preferences and system specifics.
