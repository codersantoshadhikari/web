+++
chatsper = true
title = 'Variables'
weight = 2
+++


# Variables in Dart

Dart is a strongly typed programming language that uses both static and dynamic typing. Here's a breakdown of how variables work in Dart:

## Declaring Variables

Variables in Dart can be declared in various ways depending on whether you want to explicitly specify the type or let the Dart compiler infer it for you.

### Explicitly Typed

You can declare a variable with a specific type:

```dart
void main() {
  int age = 30;

  double price = 15.50;

  String name = "John Doe";

  bool isRegistered = true;

  print("Name: $name, Age: $age, Price: $price, Registered: $isRegistered");
}

```
[Run Online ](https://dartpad.dev/?id=016096a3bd6b51a0b6a4bfffde18a0fb) 

