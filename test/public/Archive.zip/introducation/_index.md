+++
chatsper = true
title = 'Introducation'
weight = 1
+++

## Introduction to Dart
Dart is a programming language developed by Google, primarily used for building web, server, and mobile applications. It's also the programming language behind Flutter, Google's UI toolkit for building natively compiled applications for mobile, web, and desktop from a single codebase.
### How to Install Dart
To install Dart, you can download the Dart SDK from the official Dart website. For most users, it's recommended to install Dart as part of the Flutter SDK, which includes the Dart SDK by default.
1. Download the Dart SDK: Dart SDK Download
2. Follow the installation instructions for your specific platform (Windows, macOS, Linux).
### Basic Dart Program
Here's a simple Dart program that prints "Hello, World!":
dart

Copy code
void main() { print('Hello, World!'); }
### Variables in Dart
Variables in Dart are placeholders used to store data. Here's how to declare variables:
dart

Copy code
void main() { var name = 'John'; // Automatically inferred to be of type String print(name); }
### Datatypes in Dart
Dart is an optionally typed language, which means you can use it as a dynamically typed language or define explicit types. Common datatypes include int, double, String, bool, and more.
dart

Copy code
void main() { int age = 30; double height = 5.11; String name = 'Alice'; bool isRegistered = true; }
### Comments in Dart
Comments in Dart are used to explain code and are not executed. Single-line comments start with //, and multi-line comments are enclosed between /* and */.
dart

Copy code
void main() { // This is a single-line comment print('Hello, Dart!'); /* This is a multi-line comment. It spans multiple lines. */ }
### Operators in Dart
Dart supports various operators, such as arithmetic, relational, and logical operators. Here’s a brief example using arithmetic operators:
dart

Copy code
void main() { int a = 10; int b = 20; print(a + b); // Outputs 30 }
### User Input in Dart
To handle user input in Dart, you can use the stdin from the dart:io library. Here's how to read a line of text from the terminal:
dart

Copy code
import 'dart:io'; void main() { print('Enter your name:'); String? name = stdin.readLineSync(); print('Hello, $name!'); }
### String in Dart
Strings in Dart are a sequence of characters. They can be defined using single or double quotes. Dart supports string interpolation and multi-line strings.
dart

Copy code
void main() { String name = 'John'; print('Hello, $name!'); // String interpolation String quote = '''This is a multi-line string.'''; print(quote); }
