+++
chatper = true
title = 'Null Safety In Dart In Dart'
weight = 12
+++
### Null Safety in Dart
1. Null Safety in Dart
Null safety ensures that variables cannot hold null values unless you explicitly declare them to do so. This helps in creating safer, more predictable code.
Example:
dart

Copy code
int a = 10; // Non-nullable by default, cannot be null int? b = null; // Nullable, can hold a null value
2. Type Promotion in Dart
Type promotion in Dart helps the compiler recognize when it's safe to treat a variable as a non-nullable type after certain checks have been performed.
Example:
dart

Copy code
int? maybeNumber; if (maybeNumber != null) { // Dart promotes `maybeNumber` to `int` inside this scope int sum = maybeNumber + 20; }
3. Late Keyword in Dart
The late keyword in Dart is used when you declare a non-nullable variable but cannot initialize it at the point of declaration. It defers initialization until later.
Example:
dart

Copy code
late int value; void initializeValue() { value = 10; // Initialized later }
4. Null Safety Exercise
This typically involves rewriting code to make it comply with Dart’s null safety features, ensuring variables are correctly handled as nullable or non-nullable.
Exercise Example:
Convert this non-null safe Dart code:
dart

Copy code
int? number; int sum = number + 10; // Error: number might be null
Solution:
dart

Copy code
int? number;
int sum = number ?? 0 + 10; // Use the null-coalescing operator `??` to provide a default value if `number` is null.

